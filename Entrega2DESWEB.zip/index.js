import express from 'express';
import { engine } from 'express-handlebars';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import { neon } from '@neondatabase/serverless';

const app = express();

// Middleware para autenticar JWT
const authenticateJWT = (req, res, next) => {
  const token = req.cookies.token;
  
  if (token) {
    jwt.verify(token, 'admin', (err, user) => {
      if (err) {
        console.error("Error verificando JWT:", err);
        req.user = null;
        return next();
      }
      req.user = user;
      next();
    });
  } else {
    req.user = null;
    next();
  }
};

const requireAuth = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ message: 'No autorizado' });
  }
  next();
};

const getUserBalance = async (req, res, next) => {
  if (req.user && req.user.user_id) {
    try {
      const result = await sql`
        SELECT balance FROM usuarios WHERE user_id = ${req.user.user_id}
      `;
      res.locals.balance = result[0]?.balance || 0;
      console.log('Balance obtenido:', res.locals.balance);
    } catch (error) {
      console.error('Error al obtener el balance:', error);
      res.locals.balance = 0;
    }
  } else {
    res.locals.balance = 0;
  }
  next();
};

// Configura la conexión a Neon
const sql = neon('postgresql://neondb_owner:qBuw3OgoUJE1@ep-summer-dew-a5pdrk4m.us-east-2.aws.neon.tech/neondb?sslmode=require');

const validateNumber = (num) => {
  return !isNaN(num) && Number(num) > 0;
};

const handleError = (error, res) => {
  console.error('Error:', error);
  return res.status(500).json({
    success: false,
    message: 'Error interno del servidor'
  });
};

// Comprueba la conexión inicial
sql('SELECT NOW()')
  .then(() => console.log('Conexión exitosa a la base de datos'))
  .catch(error => console.error('Error en la conexión a la base de datos:', error));

// Configura Handlebars
app.engine('handlebars', engine({
  helpers: {
    multiply: (a, b) => a * b
  }
}));
app.set('view engine', 'handlebars');
app.set('views', './views');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(authenticateJWT);
app.use(getUserBalance);
app.use('/files', express.static('public'));

async function totalAPagar(userId) {
  const items = await sql`
      SELECT SUM(p.precio * c.cantidad) AS total
      FROM carritos c
      JOIN productos p ON c.producto_id = p.producto_id
      WHERE c.user_id = ${userId}
  `;
  return items[0].total || 0;
}

// Middleware para calcular el total del carrito del usuario autenticado
app.use(async (req, res, next) => {
  if (req.user) {
    try {
      const total = await totalAPagar(req.user.user_id);
      res.locals.totalAPagar = total;
    } catch (error) {
      console.error("Error al obtener el total del carrito:", error);
      res.locals.totalAPagar = 0;
    }
  } else {
    res.locals.totalAPagar = 0;
  }
  next();
});

const crearAdmin = async () => {
  const hashedPassword = bcrypt.hashSync('admin', 10); 

  try {
    await sql`
      INSERT INTO usuarios (nombre, apellidos, email, password, is_admin)
      VALUES ('Admin', 'Usuario', 'admin@admin.com', ${hashedPassword}, true)
      ON CONFLICT (email) DO NOTHING;  -- Evita duplicados si el admin ya existe
    `;
    console.log('Usuario administrador creado');
  } catch (error) {
    console.error('Error al crear el usuario administrador:', error);
  }
};

// Llama a la función al inicio de tu aplicación
crearAdmin(); 

// Ruta principal
app.get('/', async (req, res) => {
  try {
    const productos = await sql`SELECT * FROM productos`;
    res.render('index', { 
      productos,
      isAuthenticated: !!req.user,
      balance: res.locals.balance
    });
  } catch (error) {
    console.error('Error al obtener productos:', error);
    res.render('index', { 
      productos: [],
      isAuthenticated: !!req.user,
      balance: res.locals.balance
    });
  }
});

app.get('/carrito', requireAuth, async (req, res) => {
  const userId = req.user.user_id;
  try {
    const carritoItems = await sql`
      SELECT 
        p.producto_id, 
        p.nombre, 
        p.precio, 
        p.imagen_url, 
        c.cantidad, 
        (p.precio * c.cantidad) AS total
      FROM carritos c
      JOIN productos p ON c.producto_id = p.producto_id
      WHERE c.user_id = ${userId}
    `;

    const totalAPagar = carritoItems.reduce((sum, item) => sum + Number(item.total), 0);

    res.render('carrito', { 
      carritoItems, 
      totalAPagar,
      balance: res.locals.balance,
      isAuthenticated: true
    });
  } catch (error) {
    console.error('Error al obtener el carrito:', error);
    res.render('carrito', { 
      carritoItems: [], 
      totalAPagar: 0,
      balance: res.locals.balance,
      isAuthenticated: true
    });
  }
});

app.post('/carrito', requireAuth, async (req, res) => {
  const { producto_id, cantidad } = req.body;
  const userId = req.user.user_id;

  if (!producto_id || !cantidad || cantidad <= 0) {
    return res.status(400).json({ message: 'Datos inválidos' });
  }

  try {
    const producto = await sql`
      SELECT producto_id FROM productos WHERE producto_id = ${producto_id}
    `;

    if (!producto.length) {
      return res.status(404).json({ message: 'Producto no encontrado' });
    }

    const carritoExistente = await sql`
      SELECT carrito_id, cantidad FROM carritos 
      WHERE user_id = ${userId} AND producto_id = ${producto_id}
    `;

    if (carritoExistente.length > 0) {
      await sql`
        UPDATE carritos 
        SET cantidad = cantidad + ${cantidad}
        WHERE user_id = ${userId} AND producto_id = ${producto_id}
      `;
    } else {
      await sql`
        INSERT INTO carritos (user_id, producto_id, cantidad)
        VALUES (${userId}, ${producto_id}, ${cantidad})
      `;
    }

    const total = await totalAPagar(userId);
    
    return res.json({ 
      success: true, 
      message: 'Producto añadido al carrito',
      totalAPagar: total
    });
  } catch (error) {
    console.error("Error al añadir al carrito:", error);
    return res.status(500).json({ 
      success: false,
      message: 'Error al añadir producto al carrito'
    });
  }
});

// Formularios
app.get('/formulariocreacion', (req, res) => {
  res.render('formulariocreacion');
});

app.get('/formularioedicion', (req, res) => {
  res.render('formularioedicion');
});

app.get('/registro', (req, res) => {
  res.render('registro');
});

app.post('/registro', async (req, res) => {
  const { nombre, apellidos, email, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);

  try {
    const userResult = await sql`
      INSERT INTO usuarios (nombre, apellidos, email, password)
      VALUES (${nombre}, ${apellidos}, ${email}, ${hashedPassword})
      RETURNING user_id
    `;
    
    res.redirect('/login');
  } catch (error) {
    console.error('Error al registrar el usuario:', error);
    return res.render('registro', { error: 'Error al registrar el usuario. Intenta nuevamente.' });
  }
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await sql`SELECT * FROM usuarios WHERE email = ${email}`;
    const user = result[0];

    if (user && bcrypt.compareSync(password, user.password)) {
      const token = jwt.sign({ user_id: user.user_id, is_admin: user.is_admin }, 'admin', { expiresIn: '1h' });
      res.cookie('token', token, { httpOnly: true, maxAge: 1000 * 60 * 60 });

      return res.redirect('/');
    } else {
      return res.render('login', { error: 'Usuario o contraseña incorrecta. Inténtalo de nuevo.' });
    }
  } catch (error) {
    console.error('Error al iniciar sesión:', error);
    return res.render('login', { error: 'Error al procesar la solicitud. Inténtalo más tarde.' });
  }
});

app.get('/recibos', (req, res) => {
  res.render('recibos');
});

app.get('/wallet', requireAuth, async (req, res) => {
  const userId = req.user.id;
  
  try {
    const result = await sql`SELECT balance FROM usuarios WHERE user_id = ${userId}`;
    const balance = result[0]?.balance || 0;
    
    res.render('wallet', { balance });
  } catch (error) {
    console.error('Error al obtener el balance de la wallet:', error);
    res.render('wallet', { balance: 0 });
  }
});

// Ruta para procesar la compra
app.post('/checkout', requireAuth, async (req, res) => {
  const userId = req.user.user_id;

  try {
    // Obtener el total a pagar del carrito
    const total = await totalAPagar(userId);

    // Verificar si el usuario tiene suficiente saldo
    const userBalanceResult = await sql`
      SELECT balance FROM usuarios WHERE user_id = ${userId}
    `;
    const userBalance = userBalanceResult[0]?.balance || 0;

    if (userBalance < total) {
      // Saldo insuficiente
      return res.status(400).json({
        success: false,
        message: 'Saldo insuficiente en la wallet'
      });
    }

    // Descontar el saldo del usuario
    await sql`
      UPDATE usuarios 
      SET balance = balance - ${total} 
      WHERE user_id = ${userId}
    `;

    // Registrar el recibo en la base de datos
    await sql`
      INSERT INTO recibos (user_id, monto) 
      VALUES (${userId}, ${total})
    `;

    // Vaciar el carrito del usuario
    await sql`
      DELETE FROM carritos 
      WHERE user_id = ${userId}
    `;

    // Respuesta exitosa
    res.json({
      success: true,
      message: 'Compra realizada con éxito',
      newBalance: userBalance - total
    });
  } catch (error) {
    console.error('Error al procesar la compra:', error);
    return res.status(500).json({
      success: false,
      message: 'Error al realizar la compra'
    });
  }
});

app.post('/recargar-wallet', authenticateJWT, async (req, res) => {
  const userId = req.user.user_id; // Cambiar id a user_id
  const { monto } = req.body;

  if (monto <= 0) {
    return res.status(400).json({ message: 'El monto debe ser mayor que cero.' });
  }

  try {
    const result = await sql`
      UPDATE usuarios
      SET balance = balance + ${monto}
      WHERE user_id = ${userId}
      RETURNING balance
    `;

    // Verificar que el resultado no esté vacío
    if (!result || result.length === 0) {
      return res.status(400).json({ message: 'No se encontró el usuario o no se pudo actualizar el balance.' });
    }

    const newBalance = result[0].balance;

    return res.json({ message: 'Recarga exitosa', newBalance: newBalance });
  } catch (error) {
    console.error('Error al recargar wallet:', error);
    return res.status(500).json({ message: 'Error al recargar wallet. Por favor, intenta nuevamente.' });
  }
});

app.get('/administracion', requireAuth, async (req, res) => {
  if (!req.user || !req.user.is_admin) {
    return res.status(403).send('Acceso denegado');
  }

  try {
    const productos = await sql`SELECT * FROM productos`;
    console.log('Productos encontrados:', productos); // Verifica los productos
    res.render('administracion', {
      productos,
      totalAPagar: res.locals.totalAPagar,
      balance: res.locals.balance
    });
  } catch (error) {
    console.error('Error al obtener productos:', error);
    res.render('administracion', {
      productos: [],
      totalAPagar: res.locals.totalAPagar,
      balance: res.locals.balance
    });
  }
});

// Inicia el servidor
app.listen(3000, () => console.log('Servidor listo en puerto 3000'));


